/*******************************************************************************
 * Copyright (c) 2011 itemis GmbH.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Nirmal Sasidharan - initial API and implementation
 ******************************************************************************/
package org.eclipse.rmf.reqif10.model.test;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.compare.diff.metamodel.DiffElement;
import org.eclipse.emf.compare.diff.metamodel.DiffModel;
import org.eclipse.emf.compare.diff.metamodel.ReferenceOrderChange;
import org.eclipse.emf.compare.diff.service.DiffService;
import org.eclipse.emf.compare.match.MatchOptions;
import org.eclipse.emf.compare.match.metamodel.MatchModel;
import org.eclipse.emf.compare.match.service.MatchService;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.rmf.reqif10.resource.ReqIf1ResourceFactoryImpl;
import org.eclipse.rmf.reqif10.xsd.DocumentRoot;
import org.eclipse.rmf.reqif10.xsd.ReqifPackage;
import org.eclipse.rmf.reqif10.xsd.impl.DocumentRootImpl;
import org.eclipse.rmf.reqif10.xsd.util.ReqifResourceFactoryImpl;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;

public class ReqIfResourceTestBase {

	protected ResourceSet rifResourceSet;
	protected ResourceSet rifXSDResourceSet;

	@Before
	public void setup() {

		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put(
				"reqif", new ReqIf1ResourceFactoryImpl());
		rifResourceSet = new ResourceSetImpl();

		rifXSDResourceSet = new ResourceSetImpl();
		rifXSDResourceSet.getResourceFactoryRegistry()
				.getExtensionToFactoryMap()
				.put("reqif", new ReqifResourceFactoryImpl());
		rifXSDResourceSet.getResourceFactoryRegistry()
				.getProtocolToFactoryMap()
				.put(ReqifPackage.eNS_URI, ReqifPackage.eINSTANCE);

	}

	@After
	public void tearDown() throws Exception {
	}

	public static Resource loadRif(String filename) {
		ResourceSet rifResourceSet = new ResourceSetImpl();

		Resource rifResource = rifResourceSet.getResource(
				URI.createFileURI(new File(filename).getAbsolutePath()), true);
		return rifResource;
	}

	public void saveRif(Resource resource, String filename) {
		resource.setURI(URI.createFileURI(new File(filename).getAbsolutePath()));
		try {
			resource.save(Collections.EMPTY_MAP);
		} catch (IOException e) {
			fail(e.getMessage());
		}

	}

	@SuppressWarnings("unchecked")
	public void compareModels(String filename1, String filename2) {

		Resource rifXSDResourceInput = rifXSDResourceSet.getResource(
				URI.createFileURI(new File(filename1).getAbsolutePath()), true);

		Resource rifXSDResourceOutput = rifXSDResourceSet.getResource(
				URI.createFileURI(new File(filename2).getAbsolutePath()), true);

		try {

			MatchModel match = MatchService.doMatch(
					(DocumentRootImpl) rifXSDResourceOutput.getContents()
							.get(0), rifXSDResourceInput.getContents().get(0),
					(Map<String, Object>) new HashMap<String, Object>().put(
							MatchOptions.OPTION_IGNORE_XMI_ID, Boolean.TRUE));
			DiffModel diff = DiffService.doDiff(match, false);

			ArrayList<DiffElement> differences = null;

			if (!diff.getDifferences().isEmpty()) {
				differences = getValidDifferences(diff);
				printAllDifferences(diff);
			}
			
			Assert.assertTrue((differences != null ? differences.size() : "")
					+ " Difference(s) found between loaded and saved models",
					differences == null || differences.isEmpty());
		} catch (InterruptedException e) {
			fail(e.getMessage());
		}
	}

	protected void printAllDifferences(DiffModel diff) {
		for (DiffElement diffElement : diff.getDifferences()){
			System.out.println(diffElement);
		}
	}
	
	protected ArrayList<DiffElement> getValidDifferences(DiffModel diff) {

		ArrayList<DiffElement> differences = new ArrayList<DiffElement>();

		for (DiffElement diffElement : diff.getDifferences()) {

			if (!(diffElement instanceof ReferenceOrderChange && ((ReferenceOrderChange) diffElement)
					.getLeftElement() instanceof DocumentRoot)) {
				differences.add(diffElement);
			}
		}
		return differences;
	}
}
