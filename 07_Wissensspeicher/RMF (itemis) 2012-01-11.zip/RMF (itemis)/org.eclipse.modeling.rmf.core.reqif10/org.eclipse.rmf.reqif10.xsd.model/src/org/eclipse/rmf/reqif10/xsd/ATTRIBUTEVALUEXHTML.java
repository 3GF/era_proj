/*******************************************************************************
 * Copyright (c) 2011 itemis GmbH.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Nirmal Sasidharan - initial API and implementation
 ******************************************************************************/

package org.eclipse.rmf.reqif10.xsd;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ATTRIBUTEVALUEXHTML</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.rmf.reqif10.xsd.ATTRIBUTEVALUEXHTML#getTHEVALUE <em>THEVALUE</em>}</li>
 *   <li>{@link org.eclipse.rmf.reqif10.xsd.ATTRIBUTEVALUEXHTML#getTHEORIGINALVALUE <em>THEORIGINALVALUE</em>}</li>
 *   <li>{@link org.eclipse.rmf.reqif10.xsd.ATTRIBUTEVALUEXHTML#getDEFINITION <em>DEFINITION</em>}</li>
 *   <li>{@link org.eclipse.rmf.reqif10.xsd.ATTRIBUTEVALUEXHTML#isISSIMPLIFIED <em>ISSIMPLIFIED</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.rmf.reqif10.xsd.ReqifPackage#getATTRIBUTEVALUEXHTML()
 * @model extendedMetaData="name='ATTRIBUTE-VALUE-XHTML' kind='elementOnly'"
 * @generated
 */
public interface ATTRIBUTEVALUEXHTML extends EObject {
	/**
	 * Returns the value of the '<em><b>THEVALUE</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>THEVALUE</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>THEVALUE</em>' containment reference.
	 * @see #setTHEVALUE(XHTMLCONTENT)
	 * @see org.eclipse.rmf.reqif10.xsd.ReqifPackage#getATTRIBUTEVALUEXHTML_THEVALUE()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='THE-VALUE' namespace='##targetNamespace'"
	 * @generated
	 */
	XHTMLCONTENT getTHEVALUE();

	/**
	 * Sets the value of the '{@link org.eclipse.rmf.reqif10.xsd.ATTRIBUTEVALUEXHTML#getTHEVALUE <em>THEVALUE</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>THEVALUE</em>' containment reference.
	 * @see #getTHEVALUE()
	 * @generated
	 */
	void setTHEVALUE(XHTMLCONTENT value);

	/**
	 * Returns the value of the '<em><b>THEORIGINALVALUE</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>THEORIGINALVALUE</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>THEORIGINALVALUE</em>' containment reference.
	 * @see #setTHEORIGINALVALUE(XHTMLCONTENT)
	 * @see org.eclipse.rmf.reqif10.xsd.ReqifPackage#getATTRIBUTEVALUEXHTML_THEORIGINALVALUE()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='THE-ORIGINAL-VALUE' namespace='##targetNamespace'"
	 * @generated
	 */
	XHTMLCONTENT getTHEORIGINALVALUE();

	/**
	 * Sets the value of the '{@link org.eclipse.rmf.reqif10.xsd.ATTRIBUTEVALUEXHTML#getTHEORIGINALVALUE <em>THEORIGINALVALUE</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>THEORIGINALVALUE</em>' containment reference.
	 * @see #getTHEORIGINALVALUE()
	 * @generated
	 */
	void setTHEORIGINALVALUE(XHTMLCONTENT value);

	/**
	 * Returns the value of the '<em><b>DEFINITION</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>DEFINITION</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>DEFINITION</em>' containment reference.
	 * @see #setDEFINITION(DEFINITIONType3)
	 * @see org.eclipse.rmf.reqif10.xsd.ReqifPackage#getATTRIBUTEVALUEXHTML_DEFINITION()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='DEFINITION' namespace='##targetNamespace'"
	 * @generated
	 */
	DEFINITIONType3 getDEFINITION();

	/**
	 * Sets the value of the '{@link org.eclipse.rmf.reqif10.xsd.ATTRIBUTEVALUEXHTML#getDEFINITION <em>DEFINITION</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>DEFINITION</em>' containment reference.
	 * @see #getDEFINITION()
	 * @generated
	 */
	void setDEFINITION(DEFINITIONType3 value);

	/**
	 * Returns the value of the '<em><b>ISSIMPLIFIED</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>ISSIMPLIFIED</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ISSIMPLIFIED</em>' attribute.
	 * @see #isSetISSIMPLIFIED()
	 * @see #unsetISSIMPLIFIED()
	 * @see #setISSIMPLIFIED(boolean)
	 * @see org.eclipse.rmf.reqif10.xsd.ReqifPackage#getATTRIBUTEVALUEXHTML_ISSIMPLIFIED()
	 * @model unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Boolean"
	 *        extendedMetaData="kind='attribute' name='IS-SIMPLIFIED'"
	 * @generated
	 */
	boolean isISSIMPLIFIED();

	/**
	 * Sets the value of the '{@link org.eclipse.rmf.reqif10.xsd.ATTRIBUTEVALUEXHTML#isISSIMPLIFIED <em>ISSIMPLIFIED</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>ISSIMPLIFIED</em>' attribute.
	 * @see #isSetISSIMPLIFIED()
	 * @see #unsetISSIMPLIFIED()
	 * @see #isISSIMPLIFIED()
	 * @generated
	 */
	void setISSIMPLIFIED(boolean value);

	/**
	 * Unsets the value of the '{@link org.eclipse.rmf.reqif10.xsd.ATTRIBUTEVALUEXHTML#isISSIMPLIFIED <em>ISSIMPLIFIED</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetISSIMPLIFIED()
	 * @see #isISSIMPLIFIED()
	 * @see #setISSIMPLIFIED(boolean)
	 * @generated
	 */
	void unsetISSIMPLIFIED();

	/**
	 * Returns whether the value of the '{@link org.eclipse.rmf.reqif10.xsd.ATTRIBUTEVALUEXHTML#isISSIMPLIFIED <em>ISSIMPLIFIED</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>ISSIMPLIFIED</em>' attribute is set.
	 * @see #unsetISSIMPLIFIED()
	 * @see #isISSIMPLIFIED()
	 * @see #setISSIMPLIFIED(boolean)
	 * @generated
	 */
	boolean isSetISSIMPLIFIED();

} // ATTRIBUTEVALUEXHTML
